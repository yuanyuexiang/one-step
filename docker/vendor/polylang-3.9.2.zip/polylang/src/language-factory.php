<?php
/**
 * @package Polylang
 */

use WP_Syntex\Polylang\Options\Options;

/**
 * PLL_Language factory.
 *
 * @since 3.4
 *
 * @phpstan-import-type LanguageData from PLL_Language
 */
class PLL_Language_Factory {
	/**
	 * Predefined languages.
	 *
	 * @var array[]
	 *
	 * @phpstan-var array<string, array<string, string>>
	 */
	private static $languages;

	/**
	 * Polylang's options.
	 *
	 * @var Options
	 */
	private $options;

	/**
	 * Constructor.
	 *
	 * @since 3.4
	 * @since 3.7 The `$options` parameter is an instance of `Options`.
	 *
	 * @param Options $options Poylang's options.
	 * @return void
	 */
	public function __construct( Options $options ) {
		$this->options = $options;
	}

	/**
	 * Returns a language object matching the given data, looking up in cached transient.
	 *
	 * @since 3.4
	 *
	 * @param array $language_data Language object properties stored as an array. See `PLL_Language::__construct()`
	 *                             for information on accepted properties.
	 *
	 * @return PLL_Language A language object if given data pass sanitization.
	 *
	 * @phpstan-param LanguageData $language_data
	 */
	public function get( $language_data ) {
		return new PLL_Language( $this->sanitize_data( $language_data ) );
	}

	/**
	 * Returns a language object based on terms.
	 *
	 * @since 3.4
	 *
	 * @param WP_Term[] $terms List of language terms, with the language taxonomy names as array keys.
	 *                         `language` is a mandatory key for the object to be created,
	 *                         `term_language` should be too in a fully operational environment.
	 * @return PLL_Language|null Language object on success, `null` on failure.
	 *
	 * @phpstan-param array{language?:WP_Term}&array<string, WP_Term> $terms
	 */
	public function get_from_terms( array $terms ) {
		if ( ! isset( $terms['language'] ) ) {
			return null;
		}

		$languages = $this->get_languages();
		$data      = array(
			'name'       => $terms['language']->name,
			'slug'       => $terms['language']->slug,
			'term_group' => $terms['language']->term_group,
			'term_props' => array(),
			'is_default' => $this->options['default_lang'] === $terms['language']->slug,
		);

		foreach ( $terms as $term ) {
			$data['term_props'][ $term->taxonomy ] = array(
				'term_id'          => $term->term_id,
				'term_taxonomy_id' => $term->term_taxonomy_id,
				'count'            => $term->count,
			);
		}

		$description = pll_maybe_unserialize( $terms['language']->description );
		$description = is_array( $description ) ? $description : array();

		// `locale` and `flag_code` are used before `sanitize_data()`, so check their types in case of a corrupted description.
		$data['locale']    = is_string( $description['locale'] ?? null ) ? $description['locale'] : '';
		$data['flag_code'] = is_string( $description['flag_code'] ?? null ) ? $description['flag_code'] : '';

		$data['is_rtl']    = $description['rtl'] ?? 0;
		$data['active']    = $description['active'] ?? true;
		$data['fallbacks'] = $description['fallbacks'] ?? array();

		if ( ! empty( $data['locale'] ) ) {
			if ( isset( $languages[ $data['locale'] ]['w3c'] ) ) {
				$data['w3c'] = $languages[ $data['locale'] ]['w3c'];
			} else {
				$data['w3c'] = str_replace( '_', '-', $data['locale'] );
			}

			if ( isset( $languages[ $data['locale'] ]['facebook'] ) ) {
				$data['facebook'] = $languages[ $data['locale'] ]['facebook'];
			}
		}

		$flag_props = $this->get_flag( $data['flag_code'], $data['name'], $data['slug'], $data['locale'] );
		$data       = array_merge( $data, $flag_props );

		$additional_data = array();
		/**
		 * Filters additional data to add to the language before it is created.
		 *
		 * `home_url`, `search_url`, `page_on_front` and `page_for_posts` are only allowed.
		 *
		 * @since 3.4
		 *
		 * @param array $additional_data.
		 * @param array $data Language data.
		 *
		 * @phpstan-param array<non-empty-string, mixed> $additional_data
		 * @phpstan-param non-empty-array<non-empty-string, mixed> $data
		 */
		$additional_data = apply_filters( 'pll_additional_language_data', $additional_data, $data );

		$allowed_additional_data = array(
			'home_url'       => '',
			'search_url'     => '',
			'page_on_front'  => 0,
			'page_for_posts' => 0,
		);

		$data = array_merge( $data, array_intersect_key( $additional_data, $allowed_additional_data ) );

		return new PLL_Language( $this->sanitize_data( $data ) );
	}

	/**
	 * Sanitizes data, to be ready to be used in the constructor.
	 * This doesn't verify that the language terms exist.
	 *
	 * @since 3.4
	 *
	 * @param array $data Data to process. See `PLL_Language::__construct()` for information on accepted data.
	 * @return array Sanitized Data.
	 *
	 * @phpstan-return LanguageData
	 */
	private function sanitize_data( array $data ) {
		foreach ( $data['term_props'] as $tax => $props ) {
			$data['term_props'][ $tax ] = array_map( 'absint', $props );
		}

		// A corrupted language description may lead to unexpected types.
		$data['locale']    = is_string( $data['locale'] ?? null ) ? $data['locale'] : '';
		$data['w3c']       = is_string( $data['w3c'] ?? null ) ? $data['w3c'] : '';
		$data['flag_code'] = is_string( $data['flag_code'] ?? null ) ? $data['flag_code'] : '';

		$data['is_rtl'] = ! empty( $data['is_rtl'] ) ? 1 : 0;

		$positive_fields = array( 'term_group', 'page_on_front', 'page_for_posts' );

		foreach ( $positive_fields as $field ) {
			$data[ $field ] = ! empty( $data[ $field ] ) ? absint( $data[ $field ] ) : 0;
		}

		$data['active'] = isset( $data['active'] ) ? (bool) $data['active'] : true;

		if ( array_key_exists( 'fallbacks', $data ) && ! is_array( $data['fallbacks'] ) ) {
			unset( $data['fallbacks'] );
		}

		$data['admin_flag'] = array();

		if ( ! empty( $data['flag'] ) ) {
			$data['admin_flag']['aria-hidden'] = str_replace( '<img', '<img aria-hidden="true" tabindex="-1"', $data['flag'] );
			$data['admin_flag']['']            = str_replace(
				'<img',
				sprintf(
					'<img lang="%1$s" dir="%2$s"',
					esc_attr( $data['w3c'] ),
					$data['is_rtl'] ? 'rtl' : 'ltr'
				),
				$data['flag']
			);
		} else {
			$data['admin_flag']['aria-hidden'] = sprintf( '<abbr aria-hidden="true" tabindex="-1">%s</abbr>', esc_html( strtoupper( $data['slug'] ) ) );
			$data['admin_flag']['']            = sprintf(
				'<abbr title="%1$s" lang="%2$s" dir="%3$s">%4$s</abbr>',
				esc_attr( $data['name'] ),
				esc_attr( $data['w3c'] ),
				$data['is_rtl'] ? 'rtl' : 'ltr',
				esc_html( strtoupper( $data['slug'] ) )
			);
		}

		/**
		 * @var LanguageData
		 */
		return $data;
	}

	/**
	 * Returns predefined languages data.
	 *
	 * @since 3.4
	 *
	 * @return array[]
	 *
	 * @phpstan-return array<string, array<string, string>>
	 */
	private function get_languages() {
		if ( empty( self::$languages ) ) {
			self::$languages = include POLYLANG_DIR . '/src/settings/languages.php';
		}

		return self::$languages;
	}


	/**
	 * Creates flag_url and flag language properties. Also takes care of custom flag.
	 *
	 * @since 1.2
	 * @since 3.4 Moved from `PLL_Language` to `PLL_Language_Factory` and renamed
	 *            in favor of `get_flag()` (formerly `set_flag()`).
	 *
	 * @param string $flag_code Flag code.
	 * @param string $name      Language name.
	 * @param string $slug      Language slug.
	 * @param string $locale    Language locale.
	 * @return array {
	 *     Array of the flag properties.
	 *     @type string  $flag_url        URL of the flag.
	 *     @type string  $flag            HTML markup of the flag.
	 *     @type string  $custom_flag_url Optional. URL of the custom flag if it exists.
	 *     @type string  $custom_flag     Optional. HTML markup of the custom flag if it exists.
	 * }
	 *
	 * @phpstan-return array{
	 *     flag_url: string,
	 *     flag: string,
	 *     custom_flag_url?: non-empty-string,
	 *     custom_flag?: non-empty-string
	 * }
	 */
	private function get_flag( $flag_code, $name, $slug, $locale ) {
		$flags = array(
			'flag' => PLL_Language::get_flag_information( $flag_code ),
		);

		// Custom flags?
		$directories = array(
			PLL_LOCAL_DIR,
			get_stylesheet_directory() . '/polylang',
			get_template_directory() . '/polylang',
		);

		foreach ( $directories as $dir ) {
			if ( is_readable( $file = "{$dir}/{$locale}.png" ) || is_readable( $file = "{$dir}/{$locale}.jpg" ) || is_readable( $file = "{$dir}/{$locale}.jpeg" ) || is_readable( $file = "{$dir}/{$locale}.svg" ) ) {
				$flags['custom_flag'] = array(
					'url' => content_url( '/' . str_replace( WP_CONTENT_DIR, '', $file ) ),
				);
				break;
			}
		}

		/**
		 * Filters the custom flag information.
		 *
		 * @since 2.4
		 *
		 * @param array|null $flag {
		 *   Information about the custom flag.
		 *
		 *   @type string $url    Flag url.
		 *   @type string $src    Optional, src attribute value if different of the url, for example if base64 encoded.
		 *   @type int    $width  Optional, flag width in pixels.
		 *   @type int    $height Optional, flag height in pixels.
		 * }
		 * @param string     $code Flag code.
		 */
		$flags['custom_flag'] = apply_filters( 'pll_custom_flag', empty( $flags['custom_flag'] ) ? null : $flags['custom_flag'], $flag_code );

		if ( ! empty( $flags['custom_flag']['url'] ) ) {
			if ( empty( $flags['custom_flag']['src'] ) ) {
				$flags['custom_flag']['src'] = esc_url( set_url_scheme( $flags['custom_flag']['url'], 'relative' ) );
			}

			$flags['custom_flag']['url'] = sanitize_url( $flags['custom_flag']['url'] );
		} else {
			unset( $flags['custom_flag'] );
		}

		$return = array();

		/**
		 * @var array{
		 *     flag: array{
		 *         url: string,
		 *         src: string,
		 *         width?: positive-int,
		 *         height?: positive-int
		 *     },
		 *     custom_flag?: array{
		 *         url: non-empty-string,
		 *         src: non-empty-string,
		 *         width?: positive-int,
		 *         height?: positive-int
		 *     }
		 * } $flags
		 */
		foreach ( $flags as $key => $flag ) {
			$return[ "{$key}_url" ] = $flag['url'];

			/**
			 * Filters the html markup of a flag.
			 *
			 * @since 1.0.2
			 *
			 * @param string $flag Html markup of the flag or empty string.
			 * @param string $slug Language code.
			 */
			$return[ $key ] = apply_filters(
				'pll_get_flag',
				PLL_Language::get_flag_html( $flag, $name ),
				$slug
			);
		}

		/**
		 * @var array{
		 *     flag_url: string,
		 *     flag: string,
		 *     custom_flag_url?: non-empty-string,
		 *     custom_flag?: non-empty-string
		 * } $return
		 */
		return $return;
	}
}
